﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwareness
{
    
    
        public static class Logger
        {
            private static List<ActivityLog> _logs = new List<ActivityLog>();
            private const int MaxLogs = 100;

            public static void Log(string action)
            {
                if (_logs.Count >= MaxLogs) _logs.RemoveAt(0);
                _logs.Add(new ActivityLog { Action = action, Timestamp = DateTime.Now });
            }

            public static List<ActivityLog> GetLogs() => _logs.ToList();
        }

    }
}
