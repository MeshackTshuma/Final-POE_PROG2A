﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSecurityAwareness
{
    /// <summary>
    /// Interaction logic for CybersecurityQuiz.xaml
    /// </summary>
    public partial class CybersecurityQuiz : Window
    {
        private int _currentIndex = 0;
        private int _score = 0;

        private List<(string Question, string[] Options, string Answer)> _questions = new List<(string, string[], string)>
            { //questions and answers
              
            ("What is cybersecurity?", new[]{"study of insectd","study of plants","study of fossils" },"The practice of protecting computer systems,networks, and data from digital attacks and unauthorized access," ) ,
           ("What is malware? ",new [] {"History book", "Biography", "study of religion" }, "Malware is a software designed to harm or exploit a computer system" ),
           ("What is phishing?", new []{"Synonym for fishing", "ancient sport", "Name of a planet"}, " Phishing is a type of social engineering attact where an attacker attempent to trick a victim into revealing sensitive information" ),
           ( "What is social engineering?",new[] {"Sudy of poeple" ,"Study of physiology","Another word for social media"}, "Social enginnering is a manipulation tactic used to  trick people to reveal sensitive information or performing actions that compromise their security.It exploits human trust to bypass security measures  "),
          ( "What is ransomware?",new[]{"Mens clothing","Insect","name of a star" }, "Ransomware is a type of software that encrypts a vvictim's files, demanding a ransom payment for their decryption" ),
          ( "What is Denial-of-Service and distributed Denial-of-Service?",new[]{"Denial of goverment service","Running out of air time","Loadshedding" }, "These are types of attacks overwhelm a system with traffic, making it unavailable to legitimate users"),
          ( "What is Advanced persistent threats?",new []{"a mallware", "type of social engineering", "weather condition" }, "Advanced Persistent Threats are sophisticated, long-term attacks targeting specific organizations, often involving multple attack vectors and techniques " ),
          ( "What is computer Virus?",new []{"Insects found in computers", "a chip", "outdated softwarw" }, "Virus is a type of malware that can replicate itself and spread to other computers often causing damage and software" ),
          ( "What is worm?",new []{"Soft bodied animal","Another word for computer mouse","a plant"},"Worm is a type of virus that can spread independently without needing to attach to another program or file" ),
          ( "What is Trojan Horse?",new[] {"Black horses","Wild horses", "race hotrses" },"Trojan Horse is a type of malware that disguise itself as a legitimate or harmless program to trick users into installing and running it" ),

        
        
        
        
        };

public  CybersecurityQuiz()
        {
            InitializeComponent();
            LoadQuestion();
        }

        private void LoadQuestion()
        {
            if (_currentIndex < _questions.Count)
            {
                var (q, opts, _) = _questions[_currentIndex];
                QuestionText.Text = q;
                AnswersList.ItemsSource = opts;
            }
            else
            {
                QuestionText.Text = $"Quiz Complete! Your score: {_score}/{_questions.Count}";
                AnswersList.Visibility = Visibility.Collapsed;
            }
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (_currentIndex >= _questions.Count) return;
            var selected = AnswersList.SelectedItem?.ToString();
            if (selected == _questions[_currentIndex].Answer)
                _score++;
            _currentIndex++;
            LoadQuestion();
        }
    }
}







       
  
