﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSecurityAwareness
{
    /// <summary>
    /// Interaction logic for TaskManagerWindow.xaml
    /// </summary>
    public partial class TaskManagerWindow : Window
    {
        public TaskManagerWindow()
        {//creating method to load or add tasks
            InitializeComponent();
            LoadTasks();
        }
  
        }

        private void LoadTasks()
        {
            TaskList.ItemsSource = null;
            TaskList.ItemsSource = TaskManager.Tasks.ToList();
        }
        //method to delete tasks
        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (TaskList.SelectedItem is CyberTask selected)
            {
                TaskManager.Tasks.Remove(selected);
                Logger.Log($"Task '{selected.Title}' deleted.");
                LoadTasks();
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadTasks();
        }
    }
}

