﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwareness
{
    
    
        public static class SimpleNLP
        {
            public static string ParseIntent(string input)
            {
                input = input.ToLower();
                if (input.Contains("remind") && input.Contains("password"))
                    return "remind_password";
                if (input.Contains("enable") && input.Contains("2fa"))
                    return "enable_2fa";
                if (input.Contains("privacy"))
                    return "change_privacy";
                if (input.Contains("quiz"))
                    return "start_quiz";
                if (input.Contains("view log"))
                    return "view_log";

                return "unknown";
            }
        }













    }
}
