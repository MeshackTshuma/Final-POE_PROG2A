﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwareness
{
   
    
        public class ActivityLog
        {
            public string Action { get; set; }
            public DateTime Timestamp { get; set; }

            public override string ToString()
            {
                return $"{Timestamp:G} - {Action}";
            }
        }






    }

