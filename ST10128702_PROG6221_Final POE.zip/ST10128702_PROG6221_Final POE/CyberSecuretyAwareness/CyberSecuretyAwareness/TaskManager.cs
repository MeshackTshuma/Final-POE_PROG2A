﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwareness
{
    internal class TaskManager
    {

       
        {
            public static List<CyberTask> Tasks { get; } = new List<CyberTask>();
        }




    }
}
