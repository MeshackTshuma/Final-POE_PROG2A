﻿using CyberSecurityAwareness;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CyberSecuretyAwareness
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {  //dictionary for predetermined questions and answers
        private Dictionary<string, string> _cybersecurityKnowldgeBase = new Dictionary<string, string>()
        {
           {"What is cybersecurity?", "The practice of protecting computer systems,networks, and data from digital attacks and unauthorized access,"   },
           {"What is malware? ", "Malware is a software designed to hrm or exploit a computer system"    },
           {"What is phishing?", " Phishing is a type of social engineering attact where an attacker attempent to trick a victim into revealing sensitive information" },
           {"What is social engineering?", "Social enginnering is a manipulation tactic used to  trick people to reveal sensitive information or performing actions that compromise their security.It exploits human trust to bypass security measures  "},
          {"What is ransomware?", "Ransomware is a type of software that encrypts a vvictim's files, demanding a ransom payment for their decryption" },
          {"What is Denial-of-Service and distributed Denial-of-Service?", "These are types of attacks overwhelm a system with traffic, making it unavailable to legitimate users"},
          {"What is Advanced persistent threats?", "Advanced Persistent Threats are sophisticated, long-term attacks targeting specific organizations, often involving multple attack vectors and techniques " },
          { "What is computer Virus?", "Virus is a type of malware that can replicate itself and spread to other computers often causing damage and software" },
          {"What is worm?","Worm is a type of virus that can spread independently without needing to attach to another program or file" },
          { "What is Trojan Horse?","Trojan Horse is a type of malware that disguise itself as a legitimate or harmless program to trick users into installing and running it" },
        };


        public MainWindow()
        {
            InitializeComponent();
        }
        // button for the user to ask question to the chatbot
        private void AskMeButton_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextbox.Text;
            string question = QuestionTextbox.Text;
            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(question))
            {
                string response = GetResponse(question);
                ResponseTextBlock.Text = $"Hello {name}, {response}";

            }
            else
            {

                ResponseTextBlock.Text = "Please enter your name and question";
            }
        }

        private string GetResponse(string question)
        {
            string response = "";
            foreach (var pair in _cybersecurityKnowldgeBase)
            {
                if (pair.Key.ToLower().Contains(question.ToLower()))
                {
                    response += pair.Value;
                    break;
                }

            }//default response
            if (string.IsNullOrEmpty(response))
            {
                response = "I'm not sure i understand your question. Please try rephrasing it";
            }
            return response;

            throw new NotImplementedException();
}

        private void OpenTaskManager_Click(object sender, RoutedEventArgs e)
        {
            TaskManagerWindow taskManagerWindow = new TaskManagerWindow();
            taskManagerWindow.Show();
           

        }

        private void OpenQuiz_Click(object sender, RoutedEventArgs e)
        {
            CybersecurityQuiz cybersecurityQuiz = new CybersecurityQuiz();
            cybersecurityQuiz.Show();
        }

        private void OpenLog_Click(object sender, RoutedEventArgs e)
        {
            ActivityLog activityLog = new ActivityLog();
            activityLog.Show();
        }
    }
}








